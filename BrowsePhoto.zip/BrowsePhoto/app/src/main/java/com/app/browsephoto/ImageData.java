package com.app.browsephoto;

public class ImageData {

    String  s_ImagePath;

    public ImageData() {
    }


    public String getS_ImagePath() {
        return s_ImagePath;
    }

    public void setS_ImagePath(String s_ImagePath) {
        this.s_ImagePath = s_ImagePath;
    }
}
